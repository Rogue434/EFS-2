#include <ModbusMaster.h>
#include <SoftwareSerial.h>
#include <EEPROM.h>

#define MODBUS Serial1

ModbusMaster node;
SoftwareSerial SSerial(11, 10);

String SemeatechType[41] = { "", "", "CO", "O2", "H2", "CH4", "", "CO2", "O3", "H2S", "SO2", "NH3", "CL2", "ETO", "HCL", "PH3", "", "HCN", "", "HF", "",
                             "NO", "NO2", "NOX", "CLO2", "", "", "", "", "", "", "THT", "C2H2", "C2H4", "CH2O", "", "", "", "", "CH3SH", "C2H3C" };
String ECMType[41] = { "", "", "CO", "O2", "H2", "CH4", "", "CO2", "O3", "H2S", "SO2", "NH3", "CL2", "ETO", "HCL", "PH3", "", "HCN", "", "HF", "",
                       "NO", "NO2", "NOX", "CLO2", "", "", "", "", "", "", "THT", "C2H2", "C2H4", "CH2O", "", "", "", "", "C2H3CL", "CH3SH" };
String BaudType[6] = { "115200", "56000", "43000", "19200", "9600", "4800" };
String ECMRUnit[4] = { "%LEL", "%VOL", "PPM", "PPB" };
String AQILEVEL[6] = { "Good", "Moderate", "Pool for Some", "Unhealty", "More Unhealty", "Hazardous" };
String HeaterCondition[2] = { "HEATER_OFF", "HEATER_ON" };
int analogPIN[8] = { A0, A1, A2, A3, A4, A5, A5, A7 };


String printBinary16(uint16_t value) {
  String forReturn;
  // for (int i = 15; i >= 0; i--) {  // Loop dari MSB ke LSB
  //   forReturn += (value >> i) & 1;
  // }
  for (int i = 0; i < 16; i++) {  // Loop dari LSB ke MSB
    forReturn += (value >> i) & 1;
  }
  return forReturn;
}
void printHexArray(byte* hexArray, byte arraySize);
void printByteAsHex(byte b);
void printBinary(byte b);
void writeModbus(byte* data, int panjang, bool CRCtype) {
  int i;
  uint16_t crc = 0xFFFF;
  for (byte p = 0; p < panjang; p++) {
    crc ^= data[p];
    for (i = 0; i < 8; ++i) {
      if (crc & 1)
        crc = (crc >> 1) ^ 0xA001;
      else
        crc = (crc >> 1);
    }
  }
  if (CRCtype == false) {
    MODBUS.write(data, panjang);
    MODBUS.write(lowByte(crc));
    MODBUS.write(highByte(crc));
  } else {
    MODBUS.write(data, panjang);
    MODBUS.write(highByte(crc));
    MODBUS.write(lowByte(crc));
  }
}

void writeSerial2(byte* data, int panjang, bool CRCtype) {
  int i;
  uint16_t crc = 0xFFFF;
  for (byte p = 0; p < panjang; p++) {
    crc ^= data[p];
    for (i = 0; i < 8; ++i) {
      if (crc & 1)
        crc = (crc >> 1) ^ 0xA001;
      else
        crc = (crc >> 1);
    }
  }
  if (CRCtype == false) {
    Serial2.write(data, panjang);
    Serial2.write(lowByte(crc));
    Serial2.write(highByte(crc));
  } else {
    Serial2.write(data, panjang);
    Serial2.write(highByte(crc));
    Serial2.write(lowByte(crc));
  }
}

byte CRC8Bit(byte* data, size_t length) {
  int sum = 0;
  for (size_t i = 0; i < length; i++) {
    sum += data[i];
  }
  return (byte)(sum & 0xFF);  // Return the low 8 bits of the sum
}

uint16_t calculateCRC(uint8_t* data, uint16_t length) {
  uint16_t crc = 0xFFFF;

  for (uint16_t i = 0; i < length; i++) {
    crc ^= data[i];  // XOR byte into least sig. byte of crc

    for (uint8_t j = 8; j != 0; j--) {  // Loop over each bit
      if ((crc & 0x0001) != 0) {        // If the LSB is set
        crc >>= 1;                      // Shift right and XOR 0xA001
        crc ^= 0xA001;
      } else {
        crc >>= 1;  // Just shift right
      }
    }
  }

  return crc;
}

bool checkCRC(uint8_t* data, uint16_t length) {
  if (length < 2) return false;  // Panjang data minimal 2 byte (untuk CRC)

  // Hitung CRC dari data (tidak termasuk 2 byte terakhir, yang berisi CRC)
  uint16_t calculatedCRC = calculateCRC(data, length - 2);

  // Ambil CRC dari data (2 byte terakhir)
  uint16_t receivedCRC = (data[length - 1] << 8) | data[length - 2];

  // Bandingkan CRC yang dihitung dengan CRC yang diterima
  return (calculatedCRC == receivedCRC);
}

String extractModbusData(uint8_t* data, uint16_t length) {
  if (length < 5) return;  // Panjang minimal 5 byte untuk ID, Function, Length, dan Data

  uint8_t slaveID = data[0];
  uint8_t functionCode = data[1];
  uint8_t dataLength = data[2];  // Jumlah byte data yang dikirim
  String forReturn;
  // Ekstrak nilai register 16-bit dinamis
  for (uint8_t i = 0; i < dataLength; i += 2) {
    uint16_t registerValue = (data[4 + i] << 8) | data[3 + i];
    forReturn += printBinary16(registerValue);
  }
  return forReturn;
}

template<typename T>
void convertToHexArray(T number, byte* hexArray, byte arraySize) {
  for (int i = 0; i < arraySize; i++) {
    hexArray[arraySize - 1 - i] = (byte)(number >> (8 * i));
  }
}

int16_t hexArrayToDecimal(byte hexArray[], int length) {
  int16_t decimalValue = 0;

  for (int i = 0; i < length; i++) {
    decimalValue = (decimalValue << 8) | hexArray[i];
  }

  return decimalValue;
}

void printByteAsHex(byte b) {
  if (b < 0x10) {
    Serial.print('0');
  }
  Serial.print(b, HEX);
  Serial.print(" ");
}

void printHexArray(byte* hexArray, byte arraySize) {
  for (byte i = 0; i < arraySize; i++) {
    if (hexArray[i] < 0x10) {
      Serial.print('0');
    }
    Serial.print(hexArray[i], HEX);
    Serial.print(" ");
  }
}

void writeStringToEEPROM(int addrOffset, const String& strToWrite) {
  byte len = strToWrite.length();
  EEPROM.write(addrOffset, len);  // Menyimpan panjang string
  for (int i = 0; i < len; i++) {
    EEPROM.write(addrOffset + 1 + i, strToWrite[i]);
  }
}

String readStringFromEEPROM(int addrOffset) {
  int newStrLen = EEPROM.read(addrOffset);
  char data[newStrLen + 1];
  for (int i = 0; i < newStrLen; i++) {
    data[i] = EEPROM.read(addrOffset + 1 + i);
  }
  data[newStrLen] = '\0';
  return String(data);
}

//getData,semeatech,1,# (getData,semeatech,[devID],#)
void getSemeatech(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(19200, SERIAL_8N1);
  delay(50);
  if (V1 < 1 || V1 > 255) {
    Serial.println("SEMEATECH;ERROR_DEVID;END_SEMEATECH;");
    return;
  }
  int readLength;

  byte buf[20];
  byte getSensorType[] = { 0x3A, V1, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00 };
  byte getSensorValue[] = { 0x3A, V1, 0x03, 0x00, 0x00, 0x06, 0x00, 0x00 };
  String SensorType;

  writeModbus(getSensorType, sizeof(getSensorType), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 6);
  } else {
    Serial.println(String("SEMEATECH_DATA;") + V1 + ";ERROR_NOT_FOUND;END_SEMEATECH_DATA;");
    return;
  }
  if (buf[0] == 0x3A) {
    SensorType = SemeatechType[buf[3]];
  }
  delay(50);
  writeModbus(getSensorValue, sizeof(getSensorValue), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 20);
  } else {
    Serial.println(String("SEMEATECH_DATA;") + V1 + ";ERROR_NOT_FOUND;END_SEMEATECH_DATA;");
    return;
  }
  if (buf[0] == 0x3A) {
    byte convertuG[] = { buf[6], buf[7], buf[8], buf[9] };
    byte convertppb[] = { buf[10], buf[11], buf[12], buf[13] };
    byte converttemp[] = { buf[14], buf[15] };
    byte converthum[] = { buf[16], buf[17] };
    int16_t uG = hexArrayToDecimal(convertuG, 4);
    int16_t ppb = hexArrayToDecimal(convertppb, 4);
    int16_t temp = hexArrayToDecimal(converttemp, 2);
    int16_t hum = hexArrayToDecimal(converthum, 2);
    float ftemp = temp;
    float fhum = hum;
    Serial.println(String("SEMEATECH_DATA;") + V1 + ";" + SensorType + ";" + uG + ";" + ppb + ";" + String((ftemp / 100), 2) + ";" + String((fhum / 100), 2) + ";END_SEMEATECH_DATA;");
  }
}

//getData,semeatech,batch,1,4,# (getData,semeatech,batch,[fromID],[toID],#)
void getbatchSemeatech(int V1, int V2) {
  Serial.println("SEMEATECH_BATCH;");
  if (V1 < 1 || V1 > 255) {
    if (V2 < 1 || V2 > 255) {
      Serial.println("ERROR_VALUE;");
      Serial.println("END_SEMEATECH_BATCH;");
      return;
    }
  }
  if (V1 > V2) {
    Serial.println("ERROR_VALUE;");
  } else if (V1 == V2) {
    getSemeatech(V1);
  } else {
    for (V1; V1 <= V2; V1++) {
      getSemeatech(V1);
    }
  }
  Serial.println("END_SEMEATECH_BATCH;");
}

//getSetting,semeatech,1,# (getSetting,semeatech,[devID],#)
void getSettingSemeatech(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(19200, SERIAL_8N1);
  delay(50);

  if (V1 < 1 || V1 > 255) {
    Serial.println("SEMEATECH_SETTING;ERROR_DEVID;END_SEMEATECH_SETTING;");
    return;
  }
  int readLength;
  byte buf[24];
  byte getData1[] = { 0x3A, V1, 0x04, 0x00, 0x20, 0x08, 0x00, 0x00 };  //Moving Average, Device ID, I2C Address, Sensor Type
  byte getData2[] = { 0x3A, V1, 0x04, 0x00, 0x30, 0x06, 0x00, 0x00 };  //Se nsitifity, Zero Value
  byte getData3[] = { 0x3A, V1, 0x04, 0x00, 0x50, 0x01, 0x00, 0x00 };  //Baudrate

  writeModbus(getData1, sizeof(getData1), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 24);
  } else {
    Serial.println(String("SEMEATECH_SETTING;") + V1 + ";ERROR_NOT_FOUND;END_SEMEATECH_SETTING;");
    return;
  }
  byte convertMA[] = { buf[14], buf[15] };
  byte convertIDS[] = { buf[16] };
  byte convertIIC[] = { buf[17] };
  byte convertST[] = { buf[20], buf[21] };
  int16_t MA = hexArrayToDecimal(convertMA, 2);
  int16_t IDS = hexArrayToDecimal(convertIDS, 1);
  int16_t IIC = hexArrayToDecimal(convertIIC, 1);
  int16_t ST = hexArrayToDecimal(convertST, 2);
  delay(50);
  writeModbus(getData2, sizeof(getData2), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 20);
  } else {
    Serial.println(String("SEMEATECH_SETTING;") + V1 + ";ERROR_NOT_FOUND;END_SEMEATECH_SETTING;");
    return;
  }
  byte convertSens[] = { buf[6], buf[7] };
  byte convertZero[] = { buf[8], buf[9] };
  int16_t Sens = hexArrayToDecimal(convertSens, 2);
  float fSens = Sens;
  int16_t Zero = hexArrayToDecimal(convertZero, 2);
  delay(50);
  writeModbus(getData3, sizeof(getData3), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 10);
  } else {
    Serial.println(String("SEMEATECH_SETTING;") + V1 + ";ERROR_NOT_FOUND;END_SEMEATECH_SETTING;");
    return;
  }
  int16_t BR = buf[7];
  Serial.println(String("SEMEATECH_SETTING;") + V1 + ";" + SemeatechType[ST] + ";" + BaudType[BR] + ";" + IIC + ";" + IDS + ";" + String((fSens / 10000), 4) + ";" + MA + ";" + Zero + ";END_SEMEATECH_SETTING;");
}

//setSetting,semeatech,1,0.9544,60,0,# (setSetting,semeatech,[devID],[newSensorSensitifity(uA/ppm)],[newMovingAverage],[NewZeroSetting],#)
void writeSettingSemeatech(int V1, String V2, String V3, String V4) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(19200, SERIAL_8N1);
  delay(50);

  int readLength;
  byte buf[24];
  if (V4.toInt() > 32767 || V4.toInt() < -32768) {
    Serial.println(String() + "WRITE_SEMEATECH;" + V1 + ";ERROR_ZERO_VALUE;END_WRITE_SEMEATECH;");
    return;
  }
  if (V3.toInt() > 32767 || V3.toInt() < -32768) {
    Serial.println(String() + "WRITE_SEMEATECH;" + V1 + ";ERROR_MOVINGAVERAGE_VALUE;END_WRITE_SEMEATECH;");
    return;
  }
  if (V2.toFloat() > 3.2767 || V2.toFloat() < -3.2768) {
    Serial.println(String() + "WRITE_SEMEATECH;" + V1 + ";ERROR_SENS_VALUE;END_WRITE_SEMEATECH;");
    return;
  }
  if (V1 < 1 || V1 > 255) {
    Serial.println("WRITE_SEMEATECH;ERROR_DEVID;END_WRITE_SEMEATECH;");
    return;
  }
  byte getSensorType[] = { 0x3A, V1, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00 };
  writeModbus(getSensorType, sizeof(getSensorType), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 6);
    Serial.print(String("WRITE_SEMEATECH;") + V1 + ";");
  } else {
    Serial.println(String("WRITE_SEMEATECH;") + V1 + ";ERROR_NOT_FOUND;END_WRITE_SEMEATECH;");
    return;
  }

  delay(50);
  uint16_t Sens = V2.toFloat() * 10000;
  byte hSens[2];
  convertToHexArray(Sens, hSens, sizeof(hSens));
  byte writeData3[] = { 0x3A, V1, 0x06, 0x00, 0x30, 0x01, hSens[0], hSens[1] };  //Sensitifity
  writeModbus(writeData3, sizeof(writeData3), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 12);
    Serial.print("SUCCESS_WRITE_SENSITIFITY;");
  } else {
    Serial.print("ERROR_WRITE_SENSITIFITY;");
  }

  delay(50);
  uint16_t MA = (uint16_t)V3.toInt();
  byte hMA[2];
  convertToHexArray(MA, hMA, sizeof(hMA));
  byte writeData1[] = { 0x3A, V1, 0x06, 0x00, 0x28, 0x01, hMA[0], hMA[1] };  //Moving Average
  writeModbus(writeData1, sizeof(writeData1), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 12);
    Serial.print("SUCCESS_WRITE_MOVING_AVERAGE;");
  } else {
    Serial.print("ERROR_WRITE_MOVING_AVERAGE;");
  }

  delay(50);
  uint16_t Zero = (uint16_t)V4.toInt();
  byte hZero[2];
  convertToHexArray(Zero, hZero, sizeof(hZero));
  byte writeData4[] = { 0x3A, V1, 0x06, 0x00, 0x32, 0x01, hZero[0], hZero[1] };  //Sensitifity
  writeModbus(writeData4, sizeof(writeData4), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 12);
    Serial.println("SUCCESS_WRITE_ZERO;END_WRITE_SEMEATECH;");
  } else {
    Serial.println("ERROR_WRITE_ZERO;END_WRITE_SEMEATECH;");
  }
}

//startFunction,semeatech,zeroCal,1,# (startFunction,semeatech,zeroCal,[devID],#)
void writeZeroCalSemeatech(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(19200, SERIAL_8N1);
  delay(50);

  if (V1 < 1 || V1 > 255) {
    Serial.println("SEMEATECH_ZERO;ERROR_DEVID;END_SEMEATECH_ZERO;");
    return;
  }


  int readLength;
  byte buf[10];
  byte writeZero[] = { 0x3A, V1, 0x07, 0x00, 0x00, 0x01, 0x00, 0x00 };
  String SensorType;

  delay(50);
  byte getSensorType[] = { 0x3A, V1, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00 };
  writeModbus(getSensorType, sizeof(getSensorType), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 6);
  } else {
    Serial.println(String("SEMEATECH_ZERO;") + V1 + ";ERROR_NOT_FOUND;END_SEMEATECH_ZERO;");
    return;
  }
  if (buf[0] == 0x3A) {
    SensorType = SemeatechType[buf[3]];
  }

  delay(50);
  writeModbus(writeZero, sizeof(writeZero), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 12);
  } else {
    Serial.println(String("SEMEATECH_ZERO;") + V1 + ";ERROR_NOT_FOUND;END_SEMEATECH_ZERO;");
    return;
  }
  byte convertZero[] = { buf[6], buf[7] };
  int16_t NZero = hexArrayToDecimal(convertZero, 2);
  Serial.println(String("SEMEATECH_ZERO;") + V1 + ";" + SensorType + ";" + NZero + ";END_SEMEATECH_ZERO");
}

//startFunction,semeatech,SCal,1,2,# (startFunction,semeatech,SCal,[devID],[CalGasValue],#)
void writeSCalSemeatech(int V1, int V2) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(19200, SERIAL_8N1);
  delay(50);
  if (V1 > 255 || V1 < 0) {
    Serial.println("SEMEATECH_SCAL;ERROR_DEVID;END_SEMEATECH_SCAL;");
    return;
  }
  if (V2 > 255 || V2 < 0) {
    Serial.println("SEMEATECH_SCAL;ERROR_SCAL_VALUE;END_SEMEATECH_SCAL;");
    return;
  }

  int readLength;
  byte buf[10];
  String SensorType;
  delay(50);
  byte getSensorType[] = { 0x3A, V1, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00 };
  writeModbus(getSensorType, sizeof(getSensorType), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 6);
  } else {
    Serial.println(String("SEMEATECH_SCAL;") + V1 + ";ERROR_NOT_FOUND;END_SEMEATECH_SCAL;");
    return;
  }
  if (buf[0] == 0x3A) {
    SensorType = SemeatechType[buf[3]];
  }
  delay(50);
  uint16_t SCal = (uint16_t)V2;
  byte hSCal[1];
  convertToHexArray(SCal, hSCal, sizeof(hSCal));
  byte writeSCal[] = { 0x3A, V1, 0x09, 0x00, 0x00, 0x01, 0x00, hSCal[0] };
  writeModbus(writeSCal, sizeof(writeSCal), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 12);
  } else {
    Serial.println(String("SEMEATECH_SCAL;") + V1 + ";ERROR_NOT_FOUND;END_SEMEATECH_SCAL;");
    return;
  }
  if (buf[3] == 0x00) {
    Serial.println(String("SEMEATECH_SCAL;") + V1 + ";" + SensorType + ";SUCCESS;END_SEMEATECH_SCAL;");
  } else if (buf[3] == 0x01) {
    Serial.println(String("SEMEATECH_SCAL;") + V1 + ";" + SensorType + ";WAIT_360_SECOND;END_SEMEATECH_SCAL;");
    unsigned long timer = 0;
    unsigned int counter = 0;
    unsigned int Lcounter = 0;
    while (counter < 361) {
      if (Serial.available() > 0) {
        Lcounter = map(counter, 0, 361, 361, 0);
        char c = Serial.read();
        if (c == '#') {
          Serial.println(String("SEMEATECH_SCAL;") + V1 + ";" + SensorType + ";WAIT_" + Lcounter + "_SECOND;END_SEMEATECH_SCAL;");
        }
      }
      if (MODBUS.available() > 0) {
        readLength = MODBUS.readBytes(buf, 12);
      }
      if (millis() - timer > 1000) {
        if (buf[0] == 0x3A && buf[3] == 0x00) {
          Serial.println(String("SEMEATECH_SCAL;") + V1 + ";" + SensorType + ";SUCCESS;END_SEMEATECH_SCAL;");
          return;
        }
        counter++;
        timer = millis();
      }
    }
    if (buf[3] == 0x00) {
      Serial.println(String("SEMEATECH_SCAL;") + V1 + ";" + SensorType + ";SUCCESS;END_SEMEATECH_SCAL;");
    } else if (buf[3] == 0x01) {
      Serial.println(String("SEMEATECH_SCAL;") + V1 + ";" + SensorType + ";FAILED;END_SEMEATECH_SCAL;");
    } else if (buf[3] == 0x02) {
      Serial.println(String("SEMEATECH_SCAL;") + V1 + ";" + SensorType + ";FAILED;END_SEMEATECH_SCAL;");
    }
  } else if (buf[3] == 0x02) {
    Serial.println(String("SEMEATECH_SCAL;") + V1 + ";" + SensorType + ";FAILED;END_SEMEATECH_SCAL;");
  }
}

//getData,4ECM,1,# (getData,4ECM,[devID],#)
void get4ECM(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  if (V1 > 255 || V1 < 0) {
    Serial.println("4ECM;ERROR_DEVID;END_4ECM;");
    return;
  }
  int readLength;
  int16_t MeasurementRange;
  int16_t CalGas;
  uint16_t Conc;
  uint16_t Comma;
  byte buf[20];
  byte readData1[] = { 0x0F, V1 };
  byte readData2[] = { 0x01, V1 };
  String SensorType = "";
  String ReadUnit = "";

  MODBUS.write(0xAA);
  writeModbus(readData1, sizeof(readData1), false);
  MODBUS.write(0xEE);
  delay(100);

  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 20);
  } else {
    Serial.println(String("4ECM;") + V1 + ";ERROR_NOT_FOUND;END_4ECM;");
    return;
  }

  if (buf[0] == 0xAA) {
    SensorType = ECMType[buf[3]];
    ReadUnit = ECMRUnit[buf[12]];
    byte convertMR[] = { buf[4], buf[5] };
    byte convertCG[] = { buf[6], buf[7] };
    MeasurementRange = hexArrayToDecimal(convertMR, 2);
    CalGas = hexArrayToDecimal(convertCG, 2);
  }
  delay(50);
  MODBUS.write(0xAA);
  writeModbus(readData2, sizeof(readData2), false);
  MODBUS.write(0xEE);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 20);
  } else {
    Serial.println(String("4ECM;") + V1 + ";ERROR_NOT_FOUND;END_4ECM;");
    return;
  }
  if (buf[0] == 0xAA) {
    byte convertConc[] = { buf[4], buf[5] };
    byte convertComma[] = { buf[6] };
    Conc = hexArrayToDecimal(convertConc, 2);
    Comma = hexArrayToDecimal(convertComma, 1);
  }
  if (buf[3] == 0x80) {
    Serial.println(String("4ECM;") + V1 + ";" + SensorType + ";-" + Conc + "." + Comma + ";" + ReadUnit + ";" + MeasurementRange + ";" + CalGas + ";END_4ECM;");
  } else if (buf[3] == 0x00) {
    Serial.println(String("4ECM;") + V1 + ";" + SensorType + ";" + Conc + "." + Comma + ";" + ReadUnit + ";" + MeasurementRange + ";" + CalGas + ";END_4ECM;");
  }
}

//startFunction,4ECM,SCal,1,# (startFunction,4ECM,SCal,[devID],#)
void writeScal4ECM(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  if (V1 > 255 || V1 < 0) {
    Serial.println("4ECM_SCAL;ERROR_DEVID;END_4ECM_SCAL;");
    return;
  }
  int readLength;
  byte buf[20];
  byte readData[] = { 0x0F, V1 };
  byte writeData[] = { 0x03, V1 };
  String SensorType = "";

  MODBUS.write(0xAA);
  writeModbus(readData, sizeof(readData), false);
  MODBUS.write(0xEE);
  delay(100);

  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 20);
  } else {
    Serial.println(String("4ECM_SCAL;") + V1 + ";ERROR_NOT_FOUND;END_4ECM_SCAL;");
    return;
  }

  if (buf[0] == 0xAA) {
    SensorType = ECMType[buf[3]];
  }
  delay(50);
  MODBUS.write(0xAA);
  writeModbus(writeData, sizeof(writeData), false);
  MODBUS.write(0xEE);
  delay(100);
  for (int i = 0; i < 20; i++) {
    buf[i] = 0x00;
  }
  Serial.println(String("4ECM_SCAL;") + V1 + ";" + SensorType + ";WAIT_180_SECOND;END_4ECM_SCAL;");
  unsigned long timer = 0;
  unsigned int counter = 0;
  unsigned int Lcounter = 0;
  while (counter < 181) {
    if (Serial.available() > 0) {
      Lcounter = map(counter, 0, 181, 181, 0);
      char c = Serial.read();
      if (c == '#') {
        Serial.println(String("4ECM_SCAL;") + V1 + ";" + SensorType + ";WAIT_" + Lcounter + "_SECOND;END_4ECM_SCAL;");
      }
    }
    if (MODBUS.available() > 0) {
      readLength = MODBUS.readBytes(buf, 20);
    }
    if (millis() - timer > 1000) {
      if (buf[0] == 0xAA) {
        if (buf[3] == 0x10) {
          Serial.println(String("4ECM_SCAL;") + V1 + ";" + SensorType + ";SUCCESS;END_4ECM_SCAL;");
          return;
        } else if (buf[3] == 0x20) {
          Serial.println(String("4ECM_SCAL;") + V1 + ";" + SensorType + ";FAILED;END_4ECM_SCAL;");
          return;
        }
      }
      counter++;
      timer = millis();
    }
  }
  Serial.println(String("4ECM_SCAL;") + V1 + ";" + SensorType + ";FAILED;END_4ECM_SCAL;");
}

//startFunction,4ECM,zeroCal,1,# (startFunction,4ECM,zeroCal,[devID],#)
void writeZeroCal4ECM(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  if (V1 > 255 || V1 < 0) {
    Serial.println("4ECM_ZERO;ERROR_DEVID;END_4ECM_ZERO;");
    return;
  }
  int readLength;
  byte buf[20];
  byte readData[] = { 0x0F, V1 };
  byte writeData[] = { 0x02, V1 };
  String SensorType = "";

  MODBUS.write(0xAA);
  writeModbus(readData, sizeof(readData), false);
  MODBUS.write(0xEE);
  delay(100);

  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 20);
  } else {
    Serial.println(String("4ECM_ZERO;") + V1 + ";ERROR_NOT_FOUND;END_4ECM_ZERO;");
    return;
  }

  if (buf[0] == 0xAA) {
    SensorType = ECMType[buf[3]];
  }
  delay(50);
  MODBUS.write(0xAA);
  writeModbus(writeData, sizeof(writeData), false);
  MODBUS.write(0xEE);
  delay(100);
  for (int i = 0; i < 20; i++) {
    buf[i] = 0x00;
  }
  Serial.println(String("4ECM_ZERO;") + V1 + ";" + SensorType + ";WAIT_60_SECOND;END_4ECM_ZERO;");
  unsigned long timer = 0;
  unsigned int counter = 0;
  unsigned int Lcounter = 0;
  while (counter < 61) {
    if (Serial.available() > 0) {
      Lcounter = map(counter, 0, 61, 61, 0);
      char c = Serial.read();
      if (c == '#') {
        Serial.println(String("4ECM_ZERO;") + V1 + ";" + SensorType + ";WAIT_" + Lcounter + "_SECOND;END_4ECM_ZERO;");
      }
    }
    if (MODBUS.available() > 0) {
      readLength = MODBUS.readBytes(buf, 20);
    }
    if (millis() - timer > 1000) {
      if (buf[0] == 0xAA) {
        if (buf[3] == 0x10) {
          Serial.println(String("4ECM_ZERO;") + V1 + ";" + SensorType + ";SUCCESS;END_4ECM_ZERO;");
          return;
        } else if (buf[3] == 0x20) {
          Serial.println(String("4ECM_ZERO;") + V1 + ";" + SensorType + ";FAILED;END_4ECM_ZERO;");
          return;
        }
      }
      counter++;
      timer = millis();
    }
  }
  Serial.println(String("4ECM_ZERO;") + V1 + ";" + SensorType + ";FAILED;END_4ECM_ZERO;");
}

//startFunction,4ECM,AdjustCalGas,1,5,# (startFunction,4ECM,AdjustCalGas,[devID],[ValueCal],#)
void writeAdjustGas4ECM(int V1, int V2) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  if (V1 > 255 || V1 < 0) {
    Serial.println("4ECM_ADJUST_GAS;ERROR_DEVID;END_4ECM_ADJUST_GAS;");
    return;
  }
  int readLength;
  byte buf[20];
  byte readData[] = { 0x0F, V1 };
  String SensorType = "";

  MODBUS.write(0xAA);
  writeModbus(readData, sizeof(readData), false);
  MODBUS.write(0xEE);
  delay(100);

  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 20);
  } else {
    Serial.println(String("4ECM_ADJUST_GAS;") + V1 + ";ERROR_NOT_FOUND;END_4ECM_ADJUST_GAS;");
    return;
  }

  if (buf[0] == 0xAA) {
    SensorType = ECMType[buf[3]];
  }

  delay(50);
  uint16_t CalVal = (uint16_t)V2;
  byte hCalVal[2];
  convertToHexArray(CalVal, hCalVal, sizeof(hCalVal));
  byte writeData[] = { 0x05, V1, hCalVal[0], hCalVal[1] };
  MODBUS.write(0xAA);
  writeModbus(writeData, sizeof(writeData), false);
  MODBUS.write(0xEE);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 20);
  } else {
    Serial.println(String("4ECM_ADJUST_GAS;") + V1 + ";ERROR_NOT_FOUND;END_4ECM_ADJUST_GAS;");
    return;
  }
  if (buf[0] == 0xAA) {
    if (buf[3] == 0x10) {
      Serial.println(String("4ECM_ADJUST_GAS;") + V1 + ";" + SensorType + ";" + V2 + ";SUCCESS;END_4ECM_ADJUST_GAS;");
    } else if (buf[3] == 0x20) {
      Serial.println(String("4ECM_ADJUST_GAS;") + V1 + ";" + SensorType + ";" + V2 + ";FAILED;END_4ECM_ADJUST_GAS;");
    }
  }
}

//getData,senovol,0,20,1,# (getData,senovol,[AnalogInPin],[PIDValue],[AREF],#)
void getSenovol(int V1, int V2, int V3) {
  if (V3 == 1) {
    analogReference(EXTERNAL);
  } else if (V3 == 0) {
    analogReference(DEFAULT);
  } else {
    Serial.println(String("SENOVOL;ERROR_WRONG_COMMAND;END_SENOVOL;"));
    return;
  }
  if (V1 > 7 || V1 < 0) {
    Serial.println("SENOVOL;ERROR_WRONG_ANALOG_PIN;END_SENOVOL;");
    return;
  }
  int readADC = analogRead(analogPIN[V1]);
  String V10 = readStringFromEEPROM(V1 * 6);
  uint32_t mapADC = map(readADC, 0, 1023, 0, (V2 * V10.toInt()));
  // float adc_voltage = analogRead(analogPIN[V1]);
  // adc_voltage = (adc_voltage * 3.3) / 1024.0;
  // float PPB2 = adc_voltage;
  // PPB2 = PPB2 * 1000;
  // PPB2 = PPB2 / 60;
  Serial.println(String("SENOVOL;") + analogPIN[V1] + ";" + mapADC + ";" + V10 + ";END_SENOVOL;");
}

//getData,winsen,0,2,# (getData,winsen,[AnalogInPin],[FullScaleValue],#)
void getWinsen(int V1, float V2) {
  if (V1 < 0 || V1 > 7) {
    Serial.println("WINSEN;ERROR_WRONG_ANALOG_PIN;END_WINSEN;");
    return;
  }
  analogReference(DEFAULT);
  float adc_voltage = analogRead(analogPIN[V1]);
  adc_voltage = (adc_voltage * 5.0) / 1024.0;
  float FlowValue = V2 * (adc_voltage - 0.5) / (4.5 - 0.5);
  Serial.println(String("WINSEN;") + analogPIN[V1] + ";" + V2 + ";" + adc_voltage + ";" + FlowValue + ";END_WINSEN");
}

//setData,senovol,multiplier,0,1000,# (setData,senovol,multiplier,[AnalogInPin],[multiplierValue],#)
void writeSenovol(int V1, String V2) {
  if (V1 > 7 || V1 < 0) {
    Serial.println("SET_SENOVOL_MULTIPLIER;ERROR_WRONG_ANALOG_PIN;END_SET_SENOVOL_MULTIPLIER;");
    return;
  }
  if (V2.toInt() > 65535 || V2.toInt() < 0) {
    Serial.println("SET_SENOVOL_MULTIPLIER;ERROR_WRONG_MULTIPLIER;END_SET_SENOVOL_MULTIPLIER;");
    return;
  }
  writeStringToEEPROM(V1 * 6, V2);
  Serial.println(String("SET_SENOVOL_MULTIPLIER;SUCCESS;") + V2 + ";END_SET_SENOVOL_MULTIPLIER");
}

//getData,PMNova,2,mode,# (getData,PMNova,[SerialPort],mode,#)
//getData,PMNova,2,conc,# (getData,PMNova,[SerialPort],conc,#)
void getNovaData(int V1, int V2) {
  int readLength;
  byte buf[20];
  byte getMode[] = { 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF };
  byte getPM[] = { 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF };

  if (V1 == 2) {
    Serial2.end();
    delay(50);
    Serial2.begin(9600, SERIAL_8N1);
    delay(50);
    Serial2.write(0xAA);
    if (V2 == 1) {
      Serial2.write(0xB4);
      Serial2.write(getMode, sizeof(getMode));
      Serial2.write(CRC8Bit(getMode, sizeof(getMode)));
    } else if (V2 == 2) {
      Serial2.write(0xB4);
      Serial2.write(getPM, sizeof(getPM));
      Serial2.write(CRC8Bit(getPM, sizeof(getPM)));
    } else {
      Serial.println("PM_NOVA;ERROR_REQUEST;END_PM_NOVA;");
    }
    Serial2.write(0xAB);
  } else if (V1 == 3) {
    Serial3.end();
    delay(50);
    Serial3.begin(9600, SERIAL_8N1);
    delay(50);
    Serial3.write(0xAA);
    if (V2 == 1) {
      Serial3.write(0xB4);
      Serial3.write(getMode, sizeof(getMode));
      Serial3.write(CRC8Bit(getMode, sizeof(getMode)));
    } else if (V2 == 2) {
      Serial3.write(0xB4);
      Serial3.write(getPM, sizeof(getPM));
      Serial3.write(CRC8Bit(getPM, sizeof(getPM)));
    } else {
      Serial.println("PM_NOVA;ERROR_REQUEST;END_PM_NOVA;");
    }
    Serial3.write(0xAB);
  } else if (V1 == 4) {
    SSerial.end();
    delay(50);
    SSerial.begin(9600);
    delay(50);
    SSerial.write(0xAA);
    if (V2 == 1) {
      SSerial.write(0xB4);
      SSerial.write(getMode, sizeof(getMode));
      SSerial.write(CRC8Bit(getMode, sizeof(getMode)));
    } else if (V2 == 2) {
      SSerial.write(0xB4);
      SSerial.write(getPM, sizeof(getPM));
      SSerial.write(CRC8Bit(getPM, sizeof(getPM)));
    } else {
      Serial.println("PM_NOVA;ERROR_REQUEST;END_PM_NOVA;");
    }
    SSerial.write(0xAB);
  } else {
    Serial.println("PM_NOVA;ERROR_SERIAL_PORT;END_PM_NOVA;");
    return;
  }

  delay(100);
  if (Serial2.available() > 0) {
    readLength = Serial2.readBytes(buf, 20);
  } else if (Serial3.available() > 0) {
    readLength = Serial3.readBytes(buf, 20);
  } else if (SSerial.available() > 0) {
    readLength = SSerial.readBytes(buf, 20);
  } else {
    Serial.println(String("PM_NOVA;ERROR_NOT_FOUND;END_PM_NOVA;"));
    return;
  }

  if (V2 == 1) {
    if (buf[1] == 0xC5 && buf[4] == 0x00) {
      Serial.println("PM_NOVA;MODE;ACTIVE_MODE;END_PM_NOVA;");
    } else if (buf[1] == 0xC5 && buf[4] == 0x01) {
      Serial.println("PM_NOVA;MODE;QUERY_MODE;END_PM_NOVA;");
    } else {
      Serial.println(String("PM_NOVA;ERROR_INVALID_DATA;END_PM_NOVA;"));
    }
  } else if (V2 == 2) {
    byte convertPM25[] = { buf[3], buf[2] };
    byte convertPM10[] = { buf[5], buf[4] };
    uint16_t PM25 = hexArrayToDecimal(convertPM25, 2);
    uint16_t PM10 = hexArrayToDecimal(convertPM10, 2);
    float fPM25 = PM25;
    float fPM10 = PM10;
    if (buf[1] == 0xC0) {
      Serial.println(String("PM_NOVA;SDS011;") + String((fPM25 / 10), 1) + ";" + String((fPM10 / 10), 1) + ";END_PM_NOVA");
    } else if (buf[1] == 0xCF) {
      Serial.println(String("PM_NOVA;SDS198;") + String((fPM10 / 10), 1) + ";END_PM_NOVA");
    } else {
      Serial.println(String("PM_NOVA;INVALID_DATA;END_PM_NOVA;"));
    }
  }
}

//setData,PMNova,2,mode,1,# (setData,PMNova,[SerialPort],mode,[0:Active_Mode, 1:Query_Mode],#)
void setNovaData(int V1, int V2, int V3) {
  int readLength;
  byte buf[20];
  if (V1 == 2) {
    Serial2.end();
    delay(50);
    Serial2.begin(9600, SERIAL_8N1);
    delay(50);
    Serial2.write(0xAA);
    if (V2 == 1) {
      Serial2.write(0xB4);
      if (V3 > 1 || V3 < 0) {
        Serial.println("SET_PM_NOVA;MODE;ERROR_VALUE;END_SET_PM_NOVA");
        return;
      }
      byte setMode[] = { 0x02, 0x01, V3, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF };
      Serial2.write(setMode, sizeof(setMode));
      Serial2.write(CRC8Bit(setMode, sizeof(setMode)));
    }
    Serial2.write(0xAB);
  } else if (V1 = 3) {
    Serial3.end();
    delay(50);
    Serial3.begin(9600, SERIAL_8N1);
    delay(50);
    Serial3.write(0xAA);
    if (V2 == 1) {
      Serial3.write(0xB4);
      if (V3 > 1 || V3 < 0) {
        Serial.println("SET_PM_NOVA;MODE;ERROR_VALUE;END_SET_PM_NOVA");
        return;
      }
      byte setMode[] = { 0x02, 0x01, V3, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF };
      Serial3.write(setMode, sizeof(setMode));
      Serial3.write(CRC8Bit(setMode, sizeof(setMode)));
    }
    Serial3.write(0xAB);
  } else if (V1 = 4) {
    SSerial.end();
    delay(50);
    SSerial.begin(9600);
    delay(50);
    SSerial.write(0xAA);
    if (V2 == 1) {
      SSerial.write(0xB4);
      if (V3 > 1 || V3 < 0) {
        Serial.println("SET_PM_NOVA;MODE;ERROR_VALUE;END_SET_PM_NOVA");
        return;
      }
      byte setMode[] = { 0x02, 0x01, V3, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF };
      SSerial.write(setMode, sizeof(setMode));
      SSerial.write(CRC8Bit(setMode, sizeof(setMode)));
    }
    SSerial.write(0xAB);
  }

  delay(100);
  if (Serial2.available() > 0) {
    readLength = Serial2.readBytes(buf, 20);
  } else if (Serial3.available() > 0) {
    readLength = Serial3.readBytes(buf, 20);
  } else if (SSerial.available() > 0) {
    readLength = SSerial.readBytes(buf, 20);
  } else {
    Serial.println(String("SET_PM_NOVA;ERROR_NOT_FOUND;END_SET_PM_NOVA;"));
    return;
  }
  if (V2 == 1) {
    if (buf[1] == 0xC5 && buf[4] == 0x00) {
      Serial.println("SET_PM_NOVA;MODE;SUCCESS;ACTIVE_MODE;END_SET_PM_NOVA;");
    } else if (buf[1] == 0xC5 && buf[4] == 0x01) {
      Serial.println("SET_PM_NOVA;MODE;SUCCESS;QUERY_MODE;END_SET_PM_NOVA;");
    } else {
      Serial.println(String("SET_PM_NOVA;INVALID_DATA;END_SET_PM_NOVA;"));
    }
  }
}

//getData,RIKA,09,#
void getRIKA9() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(1, MODBUS);
  uint8_t result = node.readHoldingRegisters(0, 5);
  if (result == node.ku8MBSuccess) {
    float ws = node.getResponseBuffer(0);
    int wd = node.getResponseBuffer(1);
    float temp = node.getResponseBuffer(2);
    float hum = node.getResponseBuffer(3);
    float pres = node.getResponseBuffer(4);
    Serial.println("RIKA_WS_09;" + String((ws / 100), 2) + ";" + wd + ";" + String((temp / 10), 1) + ";" + String((hum / 10), 1) + ";" + String((pres / 10), 1) + ";END_RIKA_WS_09;");
  } else {
    Serial.println("RIKA_WS_09;ERROR_NOT_FOUND;END_RIKA_WS_09;");
    return;
  }
}

//getData,RIKA,11,#
void getRIKA11() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8E1);
  delay(50);
  node.begin(1, MODBUS);
  uint8_t result = node.readHoldingRegisters(0, 41);
  if (result == node.ku8MBSuccess) {
    // for(int i = 0 ; i<41; i++){
    //   Serial.print(node.getResponseBuffer(i), HEX);
    //   Serial.print(" ");
    // }
    // Serial.println();
    uint16_t WindDirection = node.getResponseBuffer(1);
    uint16_t ElectronicCompas = node.getResponseBuffer(10);
    uint16_t RainorSnow = node.getResponseBuffer(11);
    uint32_t CWindSpeed = ((uint32_t)node.getResponseBuffer(3) << 16) | node.getResponseBuffer(2);
    uint32_t CAirTemp = ((uint32_t)node.getResponseBuffer(5) << 16) | node.getResponseBuffer(4);
    uint32_t CAirHum = ((uint32_t)node.getResponseBuffer(7) << 16) | node.getResponseBuffer(6);
    uint32_t CAirPres = ((uint32_t)node.getResponseBuffer(9) << 16) | node.getResponseBuffer(8);
    uint32_t CRainfall = ((uint32_t)node.getResponseBuffer(13) << 16) | node.getResponseBuffer(12);
    uint32_t CRainfallAcc = ((uint32_t)node.getResponseBuffer(15) << 16) | node.getResponseBuffer(14);
    uint32_t Illuminance = ((uint32_t)node.getResponseBuffer(31) << 16) | node.getResponseBuffer(30);
    uint32_t rowRadiation = ((uint32_t)node.getResponseBuffer(35) << 16) | node.getResponseBuffer(34);
    uint32_t Radiation = rowRadiation * 2000 / 65535;
    float WindSpeed = *(float*)&CWindSpeed;
    float AirTemp = *(float*)&CAirTemp;
    float AirHum = *(float*)&CAirHum;
    float AirPres = *(float*)&CAirPres;
    float Rainfall = *(float*)&CRainfall;
    float RainfallAcc = *(float*)&CRainfallAcc;
    Serial.print(String("RIKA_WS_11;") + 1 + ";" + WindDirection + ";" + WindSpeed + ";" + AirTemp + ";" + AirHum + ";" + AirPres + ";" + ElectronicCompas + ";" + RainorSnow + ";" + Rainfall + ";");
    Serial.println(String() + RainfallAcc + ";" + Illuminance + ";" + Radiation + ";END_RIKA_WS_11;");
  } else {
    Serial.println("RIKA_WS_11;ERROR_NOT_FOUND;END_RIKA_WS_11;");
    return;
  }
}

//setData,RIKA,11,rainaccZero,#
void setRIKA11RainAcc() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8E1);
  delay(50);
  int readLength;
  byte buf[20];
  byte writeData[] = { 0x01, 0x10, 0x00, 0x0F, 0x00, 0x02, 0x04, 0x00, 0x00, 0x00, 0x00 };
  writeModbus(writeData, sizeof(writeData), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 10);
    Serial.println("RIKA_WS_11;SET_RAINACCZERO_SUCCESS;END_RIKA_WS_11;");
  } else {
    Serial.println("RIKA_WS_11;SET_RAINACCZERO_FAILED;END_RIKA_WS_11;");
    return;
  }
}

//getData,PMBravo,#
void getPMBravo() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(115200, SERIAL_8N1);
  delay(50);
  node.begin(1, MODBUS);
  uint8_t result = node.readHoldingRegisters(100, 4);
  if (result == node.ku8MBSuccess) {
    uint16_t DPM25 = node.getResponseBuffer(0);
    uint16_t DPM10 = node.getResponseBuffer(1);
    uint16_t AQI = node.getResponseBuffer(2);
    float PM25 = DPM25;
    float PM10 = DPM10;
    Serial.println(String("PM_BRAVO;") + String((PM25 / 10), 1) + ";" + String((PM10 / 10), 1) + ";" + AQI + ";" + AQILEVEL[node.getResponseBuffer(3)] + ";END_PM_BRAVO;");
  } else {
    Serial.println("PM_BRAVO;ERROR_NOT_FOUND;END_PM_BRAVO;");
    return;
  }
}

//getData,Sentec,#
void getSentec() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(4800, SERIAL_8N1);
  delay(50);
  node.begin(1, MODBUS);
  uint8_t result = node.readHoldingRegisters(0, 1);
  if (result == node.ku8MBSuccess) {
    uint16_t SRadiation = node.getResponseBuffer(0);
    Serial.println(String("SENTEC;") + SRadiation + ";END_SENTEC;");
  } else {
    Serial.println("SENTEC;ERROR_NOT_FOUND;END_SENTEC;");
    return;
  }
}

//getData,PMOPC,#
void getOPC() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(2, MODBUS);
  uint8_t result = node.readHoldingRegisters(0, 9);
  if (result == node.ku8MBSuccess) {
    uint16_t DPM1 = node.getResponseBuffer(0);
    uint16_t DPM25 = node.getResponseBuffer(1);
    uint16_t DPM10 = node.getResponseBuffer(2);
    uint16_t DTemp = node.getResponseBuffer(3);
    uint16_t DHum = node.getResponseBuffer(4);
    uint16_t DFlow = node.getResponseBuffer(5);
    uint16_t RelayCTimer = node.getResponseBuffer(7);
    uint16_t RelayTimer = node.getResponseBuffer(8);
    float PM1 = DPM1;
    float PM25 = DPM25;
    float PM10 = DPM10;
    float Temp = DTemp;
    float Hum = DHum;
    float Flow = DFlow;
    Serial.print(String("PM_OPC;") + String((PM1 / 100), 2) + ";" + String((PM25 / 100), 2) + ";" + String((PM10 / 100), 2) + ";" + String((Temp / 100), 2) + ";");
    Serial.println(String((Hum / 100), 2) + ";" + String((Flow / 100), 2) + ";" + HeaterCondition[node.getResponseBuffer(6)] + ";" + RelayCTimer + ";" + RelayTimer + ";END_PM_OPC;");
  } else {
    Serial.println("PM_OPC;ERROR_NOT_FOUND;END_PM_OPC;");
    return;
  }
}

//setData,PMOPC,300,# (setData,PMOPC,[valueTimer],#)
void setOPC(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(2, MODBUS);
  if (V1 < 0 || V1 > 3600) {
    Serial.println("WRITE_PM_OPC;ERROR_VALUE;END_WRITE_PM_OPC;");
    return;
  }
  uint8_t result = node.writeSingleRegister(8, V1);

  if (result == node.ku8MBSuccess) {
    Serial.println(String("WRITE_PM_OPC;TIMER;") + V1 + ";SUCCESS;END_WRITE_PM_OPC;");
    return;
  } else {
    Serial.println("WRITE_PM_OPC;ERROR_NOT_FOUND;END_WRITE_PM_OPC;");
    return;
  }
}

//getData,PMMetone,11,# (setData,PMOPC,[AddressMetOne],#)
void getMetone(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  if (V1 < 0 || V1 > 255) {
    Serial.println("METONE;ERROR_DEVID;END_METONE;");
  }
  node.begin(V1, MODBUS);
  uint8_t result = node.readInputRegisters(100, 14);

  if (result == node.ku8MBSuccess) {
    for (int i = 0; i < 5; i++) {
      Serial.print("Register ");
      Serial.print(i);
      Serial.print(": 0x");
      Serial.print(node.getResponseBuffer(i), HEX);  // Print as hex
      Serial.print("\t=");
      Serial.println(node.getResponseBuffer(i));
    }
    uint32_t CConc = ((uint32_t)node.getResponseBuffer(1) << 16) | node.getResponseBuffer(0);
    uint32_t CTemp = ((uint32_t)node.getResponseBuffer(3) << 16) | node.getResponseBuffer(2);
    uint32_t CHum = ((uint32_t)node.getResponseBuffer(5) << 16) | node.getResponseBuffer(4);
    uint32_t CPres = ((uint32_t)node.getResponseBuffer(7) << 16) | node.getResponseBuffer(6);
    uint32_t CLaser = ((uint32_t)node.getResponseBuffer(11) << 16) | node.getResponseBuffer(10);
    uint32_t CFlow = ((uint32_t)node.getResponseBuffer(13) << 16) | node.getResponseBuffer(12);
    float Conc = *(float*)&CConc;
    float Temp = *(float*)&CTemp;
    float Hum = *(float*)&CHum;
    float Pres = *(float*)&CPres;
    float Laser = *(float*)&CLaser;
    float Flow = *(float*)&CFlow;
    Serial.println(String("METONE;") + Conc + ";" + Temp + ";" + Hum + ";" + Pres + ";" + Laser + ";" + Flow + ";END_METONE;");
  } else {
    Serial.println("METONE;ERROR_NOT_FOUND;END_METONE;");
    return;
  }
}

void printBinary(byte b) {
  for (int i = 0; i < 8; i++) {
    Serial.print(bitRead(b, i));  // Baca dan cetak bit dari LSB ke MSB
  }
  Serial.println();  // Pindah baris setelah mencetak semua bit
}

//getInput,PLCDelta,#
void getInputDelta() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  byte buf[20];
  byte getInput[] = { 0x03, 0x02, 0x04, 0x00, 0x00, 0x20 };
  writeModbus(getInput, sizeof(getInput), false);
  delay(100);
  uint16_t readLength;
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 20);
  } else {
    Serial.println("PLC_DELTA;ERROR_NOT_FOUND;END_PLC_DELTA;");
    return;
  }
  if (checkCRC(buf, readLength)) {
    Serial.print("PLC_DELTA;INPUT;");
    for (int i = 0; i < extractModbusData(buf, readLength).length(); i++) {
      Serial.print(extractModbusData(buf, readLength)[i]);
      Serial.print(";");
    }
    Serial.println("END_PLC_DELTA;");
  } else {
    Serial.println("PLC_DELTA;ERROR_CRC;END_PLC_DELTA;");
    return;
  }
}

//getCoils,PLCDelta,#
void getOutputDelta() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  byte buf[20];
  byte getOutput[] = { 0x03, 0x01, 0x05, 0x00, 0x00, 0x20 };
  writeModbus(getOutput, sizeof(getOutput), false);
  delay(100);
  uint16_t readLength;
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 20);
  } else {
    Serial.println("PLC_DELTA;ERROR_NOT_FOUND;END_PLC_DELTA;");
    return;
  }
  if (checkCRC(buf, readLength)) {
    Serial.print("PLC_DELTA;OUTPUT;");
    for (int i = 0; i < extractModbusData(buf, readLength).length(); i++) {
      Serial.print(extractModbusData(buf, readLength)[i]);
      Serial.print(";");
    }
    Serial.println("END_PLC_DELTA;");
  } else {
    Serial.println("PLC_DELTA;ERROR_CRC;END_PLC_DELTA;");
    return;
  }
}

bool isValidHexString(String str) {
  for (int i = 0; i < str.length(); i++) {
    char c = str.charAt(i);
    if (!isHexadecimalDigit(c)) {
      return false;
    }
  }
  return true;
}

bool isHexadecimalDigit(char c) {
  return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f');
}

//setCoils,PLCDelta,batch,0,AA,# (setCoils,PLCDelta,,batch,[OutputAddress],[AA = 10101010],#)
void setCoilsBatch(int V1, String V2) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  if (V1 < 0 || V1 > 37) {
    Serial.println("PLC_DELTA;ERROR_OUTPUT_ADDRESS;END_PLC_DELTA;");
    return;
  }
  if (isValidHexString(V2) && V2.length() <= 2) {
    uint8_t tempValue = (uint8_t)strtoul(V2.c_str(), NULL, 16);
    byte buf[20];
    int readLength;
    uint16_t coilAddress = V1 + 2148;
    byte hcoilAddress[2];
    convertToHexArray(coilAddress, hcoilAddress, sizeof(hcoilAddress));
    byte writeMultipleCoils[] = { 0x03, 0x0F, hcoilAddress[0], hcoilAddress[1], 0x00, 0x08, 0x01, tempValue };
    writeModbus(writeMultipleCoils, sizeof(writeMultipleCoils), false);
    delay(100);
    if (MODBUS.available() > 0) {
      readLength = MODBUS.readBytes(buf, 6);
      Serial.println("PLC_DELTA;WRITE_BATCH_SUCCESS;END_PLC_DELTA;");
    } else {
      Serial.println("PLC_DELTA;ERROR_NOT_FOUND;END_PLC_DELTA;");
      return;
    }
    for (int i = 0; i < 20; i++) {
      printByteAsHex(buf[i]);
    }
  } else {
    Serial.println("PLC_DELTA;ERROR_HEX_VALUE;END_PLC_DELTA;");
  }
}

//setCoils,PLCDelta,0,1,# (setCoils,PLCDelta,[OutputAddress],[0:OFF, 1:ON],#)
void setCoilsDelta(int V1, int V2) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  bool coilState;
  if (V2 == 1) {
    coilState = true;
  } else if (V2 == 0) {
    coilState = false;
  } else {
    Serial.println("PLC_DELTA;ERROR_CONDITION_VALUE;END_PLC_DELTA;");
  }
  uint16_t readLength;
  byte buf[20];
  byte set1Output[] = { 0x03, 0x05, 0x08, (0x64 + V1), coilState ? 0xFF : 0x00, 0x00 };
  byte getOutput[] = { 0x03, 0x01, 0x05, 0x00, 0x00, 0x20 };
  writeModbus(set1Output, sizeof(set1Output), false);
  delay(100);
  if (MODBUS.available() > 0) {
    readLength = MODBUS.readBytes(buf, 20);
  } else {
    Serial.println("PLC_DELTA;ERROR_NOT_FOUND;END_PLC_DELTA;");
    return;
  }
  if (checkCRC(buf, readLength)) {
    Serial.println(String("PLC_DELTA;M") + (100 + V1) + ";" + String(coilState ? "ON" : "OFF") + ";END_PLC_DELTA;");
  } else {
    Serial.println("PLC_DELTA;ERROR_CRC;END_PLC_DELTA;");
    return;
  }
  // delay(100);
  // writeModbus(getOutput, sizeof(getOutput), false);
  // delay(100);
  // if (MODBUS.available() > 0) {
  //   readLength = MODBUS.readBytes(buf, 20);
  // } else {
  //   Serial.println("PLC_DELTA;ERROR_NOT_FOUND;END_PLC_DELTA;");
  //   return;
  // }
  // if (checkCRC(buf, readLength)) {
  //   Serial.print("PLC_DELTA;OUTPUT;");
  //   for (int i = 0; i < extractModbusData(buf, readLength).length(); i++) {
  //     Serial.print(extractModbusData(buf, readLength)[i]);
  //     Serial.print(";");
  //   }
  //   Serial.println("END_PLC_DELTA;");
  // } else {
  //   Serial.println("PLC_DELTA;ERROR_CRC;END_PLC_DELTA;");
  //   return;
  // }
}

//getData,SmartPump,#
void getSmartPump() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(4, MODBUS);
  uint8_t result = node.readHoldingRegisters(0, 10);
  if (result == node.ku8MBSuccess) {
    uint16_t Auto = node.getResponseBuffer(0);
    uint16_t PWM = node.getResponseBuffer(1);
    String PUMP;
    if (node.getResponseBuffer(2) == 1) {
      PUMP = "PUMP2";
    } else {
      PUMP = "PUMP1";
    }
    uint16_t PT = node.getResponseBuffer(3);
    uint16_t PFT = node.getResponseBuffer(4);
    Serial.println(String("SMART_PUMP;") + Auto + ";" + PWM + ";" + PUMP + ";" + PT + ";" + PFT + ";END_SMART_PUMP;");
  } else {
    Serial.println("SMART_PUMP;ERROR_NOT_FOUND;END_SMART_PUMP;");
    return;
  }
}

//setData,SmartPump,Mode,1,#(setData,SmartPump,Mode,[Mode],#)
void setSmartPumpMode(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(4, MODBUS);
  if (V1 < 0 || V1 > 1) {
    Serial.println("SMART_PUMP;ERROR_VALUEu;END_SMART_PUMP;");
    return;
  }
  uint8_t result = node.writeSingleRegister(0, (uint16_t)V1);
  result = node.readHoldingRegisters(0, 10);
  if (result == node.ku8MBSuccess) {
    uint16_t Auto = node.getResponseBuffer(0);
    uint16_t PWM = node.getResponseBuffer(1);
    String PUMP;
    if (node.getResponseBuffer(2) == 1) {
      PUMP = "PUMP2";
    } else {
      PUMP = "PUMP1";
    }
    uint16_t PT = node.getResponseBuffer(3);
    uint16_t PFT = node.getResponseBuffer(4);
    Serial.println(String("SMART_PUMP;") + Auto + ";" + PWM + ";" + PUMP + ";" + PT + ";" + PFT + ";END_SMART_PUMP;");
  } else {
    Serial.println("SMART_PUMP;ERROR_NOT_FOUND;END_SMART_PUMP;");
    return;
  }
}


//setData,SmartPump,PWM,50,#(setData,SmartPump,PWM,[ValuePWM],#)
void setSmartPumpPWM(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(4, MODBUS);
  uint8_t result = node.writeSingleRegister(1, (uint16_t)V1);
  result = node.readHoldingRegisters(0, 10);
  if (result == node.ku8MBSuccess) {
    uint16_t Auto = node.getResponseBuffer(0);
    uint16_t PWM = node.getResponseBuffer(1);
    String PUMP;
    if (node.getResponseBuffer(2) == 1) {
      PUMP = "PUMP2";
    } else {
      PUMP = "PUMP1";
    }
    uint16_t PT = node.getResponseBuffer(3);
    uint16_t PFT = node.getResponseBuffer(4);
    Serial.println(String("SMART_PUMP;") + Auto + ";" + PWM + ";" + PUMP + ";" + PT + ";" + PFT + ";END_SMART_PUMP;");
  } else {
    Serial.println("SMART_PUMP;ERROR_NOT_FOUND;END_SMART_PUMP;");
    return;
  }
}

//setData,SmartPump,Timer,300,#(setData,SmartPump,PWM,[ValueTimer],#)
void setSmartPumpTimer(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(4, MODBUS);
  uint8_t result = node.writeSingleRegister(3, (uint16_t)V1);
  result = node.readHoldingRegisters(0, 10);
  if (result == node.ku8MBSuccess) {
    uint16_t Auto = node.getResponseBuffer(0);
    uint16_t PWM = node.getResponseBuffer(1);
    String PUMP;
    if (node.getResponseBuffer(2) == 1) {
      PUMP = "PUMP2";
    } else {
      PUMP = "PUMP1";
    }
    uint16_t PT = node.getResponseBuffer(3);
    uint16_t PFT = node.getResponseBuffer(4);
    Serial.println(String("SMART_PUMP;") + Auto + ";" + PWM + ";" + PUMP + ";" + PT + ";" + PFT + ";END_SMART_PUMP;");
  } else {
    Serial.println("SMART_PUMP;ERROR_NOT_FOUND;END_SMART_PUMP;");
    return;
  }
}

void togleSmartPump() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(4, MODBUS);
  uint8_t result = node.writeSingleRegister(5, 1);
  result = node.readHoldingRegisters(0, 10);
  if (result == node.ku8MBSuccess) {
    uint16_t Auto = node.getResponseBuffer(0);
    uint16_t PWM = node.getResponseBuffer(1);
    String PUMP;
    if (node.getResponseBuffer(2) == 1) {
      PUMP = "PUMP2";
    } else {
      PUMP = "PUMP1";
    }
    uint16_t PT = node.getResponseBuffer(3);
    uint16_t PFT = node.getResponseBuffer(4);
    Serial.println(String("SMART_PUMP;") + Auto + ";" + PWM + ";" + PUMP + ";" + PT + ";" + PFT + ";END_SMART_PUMP;");
  } else {
    Serial.println("SMART_PUMP;ERROR_NOT_FOUND;END_SMART_PUMP;");
    return;
  }
}

void ZeroNO2() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(8, MODBUS);
  uint8_t result = node.writeSingleRegister(1, 4354);
  if (result == node.ku8MBSuccess) {
    Serial.println(node.getResponseBuffer(0));
    // uint16_t Auto = node.getResponseBuffer(0);
    // uint16_t PWM = node.getResponseBuffer(1);
    // String PUMP;
    // if (node.getResponseBuffer(2) == 1) {
    //   PUMP = "PUMP2";
    // } else {
    //   PUMP = "PUMP1";
    // }
    // uint16_t PT = node.getResponseBuffer(3);
    // uint16_t PFT = node.getResponseBuffer(4);
    // Serial.println(String("SMART_PUMP;") + Auto + ";" + PWM + ";" + PUMP + ";" + PT + ";" + PFT + ";END_SMART_PUMP;");
  } else {
    Serial.println("SMART_PUMP;ERROR_NOT_FOUND;END_SMART_PUMP;");
    return;
  }
}

void getInVoltage() {
}

void getOPCNEW() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(2, MODBUS);
  for (int i = 0; i < 10; i++) {
    uint8_t result = node.readHoldingRegisters(0, 9);
    if (result == node.ku8MBSuccess) {
      // for(int i =0; i<8; i++){
      //   Serial.println(node.getResponseBuffer(i));
      // }
      uint16_t DPM25 = node.getResponseBuffer(3);
      uint16_t DPM10 = node.getResponseBuffer(6);
      uint16_t DFlow = node.getResponseBuffer(7);
      float PM25 = DPM25;
      float PM10 = DPM10;
      // float Temp = DTemp;
      // float Hum = DHum;
      float Flow = DFlow;
      Serial.println(String("PM_OPC;") + String((PM25 / 10), 2) + ";" + String((PM10 / 10), 2) + ";" + String((Flow / 100), 2) + ";" + node.getResponseBuffer(8) + ";END_PM_OPC;");
      return;
    } else {
    }
  }
  Serial.println("PM_OPC;ERROR_NOT_FOUND;END_PM_OPC;");
  return;
}
// for (int i = 0; i < 5; i++) {
//   Serial.print("Register ");
//   Serial.print(i);
//   Serial.print(": 0x");
//   Serial.print(node.getResponseBuffer(i), HEX); // Print as hex
//   Serial.print("\t=");
//   Serial.println(node.getResponseBuffer(i));
// }

// for (int i = 0; i < 20; i++) {
//   printByteAsHex(buf[i]);
// }

void getSmartPumpOld() {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(4, MODBUS);
  uint8_t result = node.readHoldingRegisters(0, 16);
  if (result == node.ku8MBSuccess) {
    uint16_t DAin[6] = { node.getResponseBuffer(0), node.getResponseBuffer(2), node.getResponseBuffer(4), node.getResponseBuffer(6), node.getResponseBuffer(8), node.getResponseBuffer(10) };
    float FAin[6];
    for (int i = 0; i < 7; i++) {
      FAin[i] = DAin[i];
      FAin[i] = FAin[i] / 100;
    }
    uint16_t DSLM[5] = { node.getResponseBuffer(1), node.getResponseBuffer(3), node.getResponseBuffer(5), node.getResponseBuffer(7), node.getResponseBuffer(9) };
    uint16_t Auto = node.getResponseBuffer(11);
    uint16_t PWM = node.getResponseBuffer(12);
    String PUMP;
    if (node.getResponseBuffer(13) == 1) {
      PUMP = "PUMP2";
    } else {
      PUMP = "PUMP1";
    }
    uint16_t PT = node.getResponseBuffer(14);
    uint16_t PFT = node.getResponseBuffer(15);
    Serial.print(String("SMART_PUMP;") + FAin[0] + ";" + DSLM[0] + ";" + FAin[1] + ";" + DSLM[1] + ";" + FAin[2] + ";" + DSLM[2] + ";" + FAin[3] + ";");
    Serial.println(String() + DSLM[3] + ";" + FAin[4] + ";" + DSLM[4] + ";" + FAin[5] + ";" + Auto + ";" + PWM + ";" + PUMP + ";" + PT + ";" + PFT + ";END_SMART_PUMP;");
    //
  } else {
    Serial.println("SMART_PUMP;ERROR_NOT_FOUND;END_SMART_PUMP;");
    return;
  }
}

void setSmartPumpModeOld(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(4, MODBUS);
  if (V1 < 0 || V1 > 1) {
    Serial.println("SMART_PUMP;ERROR_VALUEu;END_SMART_PUMP;");
    return;
  }
  uint8_t result = node.writeSingleRegister(11, (uint16_t)V1);
  if (result == node.ku8MBSuccess) {
    Serial.println("SMART_PUMP;WRITE_PWM_SUCCESS;END_SMART_PUMP;");
  } else {
    Serial.println("SMART_PUMP;ERROR_NOT_FOUND;END_SMART_PUMP;");
    return;
  }
}


//setData,SmartPump,PWM,50,#(setData,SmartPump,PWM,[ValuePWM],#)
void setSmartPumpPWMOld(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(4, MODBUS);
  uint8_t result = node.writeSingleRegister(12, (uint16_t)V1);
  if (result == node.ku8MBSuccess) {
    Serial.println("SMART_PUMP;WRITE_PWM_SUCCESS;END_SMART_PUMP;");
  } else {
    Serial.println("SMART_PUMP;ERROR_NOT_FOUND;END_SMART_PUMP;");
    return;
  }
}

//setData,SmartPump,Timer,300,#(setData,SmartPump,PWM,[ValueTimer],#)
void setSmartPumpTimerOld(int V1) {
  MODBUS.end();
  delay(50);
  MODBUS.begin(9600, SERIAL_8N1);
  delay(50);
  node.begin(4, MODBUS);
  uint8_t result = node.writeSingleRegister(15, (uint16_t)V1);
  if (result == node.ku8MBSuccess) {
    Serial.println("SMART_PUMP;WRITE_PWM_SUCCESS;END_SMART_PUMP;");
  } else {
    Serial.println("SMART_PUMP;ERROR_NOT_FOUND;END_SMART_PUMP;");
    return;
  }
}