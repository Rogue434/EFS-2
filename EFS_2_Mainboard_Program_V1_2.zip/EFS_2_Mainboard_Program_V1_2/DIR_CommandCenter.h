#include "DIR_CommandProcess.h"

void searchCommand(String V1[10]) {
  if (V1[0] == "getData" && V1[1] == "semeatech" && V1[2] == "batch") {  //getData,semeatech,batch,1,4,# (getData,semeatech,batch,[fromID],[toID],#)
    getbatchSemeatech(V1[3].toInt(), V1[4].toInt());
  } else if (V1[0] == "getData" && V1[1] == "semeatech") {  //getData,semeatech,1,# (getData,semeatech,[devID],#)
    getSemeatech(V1[2].toInt());
  } else if (V1[0] == "getSetting" && V1[1] == "semeatech") {  //getSetting,semeatech,1,# (getSetting,semeatech,[devID],#)
    getSettingSemeatech(V1[2].toInt());
  } else if (V1[0] == "setSetting" && V1[1] == "semeatech") {  //setSetting,semeatech,1,0.9544,60,0,# (setSetting,semeatech,[devID],[newSensorSensitifity(uA/ppm)],[newMovingAverage],[NewZeroSetting],#)
    writeSettingSemeatech(V1[2].toInt(), V1[3], V1[4], V1[5]);
  } else if (V1[0] == "startFunction" && V1[1] == "semeatech" && V1[2] == "zeroCal") {  //startFunction,semeatech,zeroCal,1,# (startFunction,semeatech,zeroCal,[devID],#)
    writeZeroCalSemeatech(V1[3].toInt());
  } else if (V1[0] == "startFunction" && V1[1] == "semeatech" && V1[2] == "SCal") {  //startFunction,semeatech,SCal,1,2,# (startFunction,semeatech,SCal,[devID],[CalGasValue],#)
    writeSCalSemeatech(V1[3].toInt(), V1[4].toInt());
  } else if (V1[0] == "getData" && V1[1] == "4ECM") {  //getData,4ECM,1,# (getData,4ECM,[devID],#)
    get4ECM(V1[2].toInt());
  } else if (V1[0] == "startFunction" && V1[1] == "4ECM" && V1[2] == "SCal") {  //startFunction,4ECM,SCal,1,# (startFunction,4ECM,SCal,[devID],#)
    writeScal4ECM(V1[3].toInt());
  } else if (V1[0] == "startFunction" && V1[1] == "4ECM" && V1[2] == "zeroCal") {  //startFunction,4ECM,zeroCal,1,# (startFunction,4ECM,zeroCal,[devID],#)
    writeZeroCal4ECM(V1[3].toInt());
  } else if (V1[0] == "startFunction" && V1[1] == "4ECM" && V1[2] == "AdjustCalGas") {  //startFunction,4ECM,AdjustCalGas,1,5,# (startFunction,4ECM,AdjustCalGas,[devID],[ValueCal],#)
    writeAdjustGas4ECM(V1[3].toInt(), V1[4].toInt());
  } else if (V1[0] == "getData" && V1[1] == "senovol") {  //getData,senovol,0,20,0,# (getData,senovol,[AnalogInPin],[PIDValue],[AREF],#)
    getSenovol(V1[2].toInt(), V1[3].toInt(), V1[4].toInt());
  } else if (V1[0] == "setData" && V1[1] == "senovol" && V1[2] == "multiplier") {  //setData,senovol,multiplier,0,1000,# (setData,senovol,multiplier,[AnalogInPin],[multiplierValue],#)
    writeSenovol(V1[3].toInt(), V1[4]);
  } else if (V1[0] == "getData" && V1[1] == "winsen") {  //getData,winsen,0,2,# (getData,winsen,[AnalogInPin],[FullScaleValue],#)
    getWinsen(V1[2].toInt(), V1[3].toFloat());
  } else if (V1[0] == "getData" && V1[1] == "PMNova" && V1[3] == "mode") {  //getData,PMNova,2,mode,# (getData,PMNova,[SerialPort],mode,#)
    getNovaData(V1[2].toInt(), 1);
  } else if (V1[0] == "getData" && V1[1] == "PMNova" && V1[3] == "conc") {  //getData,PMNova,2,conc,# (getData,PMNova,[SerialPort],conc,#)
    getNovaData(V1[2].toInt(), 2);
  } else if (V1[0] == "setData" && V1[1] == "PMNova" && V1[3] == "mode") {  //setData,PMNova,2,mode,0,# (setData,PMNova,[SerialPort],mode,[0:Active_Mode,],#)
    setNovaData(V1[2].toInt(), 1, V1[4].toInt());
  } else if (V1[0] == "getData" && V1[1] == "PMBravo") {  //getData,PMBravo,#
    getPMBravo();
  } else if (V1[0] == "getData" && V1[1] == "PMOPC") {  //getData,PMOPC,#
    getOPC();
  } else if (V1[0] == "setData" && V1[1] == "PMOPC") {  //setData,PMOPC,300,# (setData,PMOPC,[valueTimer],#)
    setOPC(V1[2].toInt());
  } else if (V1[0] == "getData" && V1[1] == "PMMetone") {  //getData,PMMetone,11,# (setData,PMOPC,[AddressMetOne],#)
    getMetone(V1[2].toInt());
  } else if (V1[0] == "getData" && V1[1] == "RIKA" && V1[2] == "09") {  //getData,RIKA,09,#
    getRIKA9();
  } else if (V1[0] == "getData" && V1[1] == "RIKA" && V1[2] == "11") {  //getData,RIKA,11,#
    getRIKA11();
  } else if (V1[0] == "setData" && V1[1] == "RIKA" && V1[2] == "11" && V1[3] == "rainaccZero") {  //setData,RIKA,11,rainaccZero,#
    setRIKA11RainAcc();
  } else if (V1[0] == "getData" && V1[1] == "Sentec") {  //getData,Sentec,#
    getSentec();
  } else if (V1[0] == "getData" && V1[1] == "InternalVoltage") {  //getData,InternalVoltage,#
    getInVoltage();
  } else if (V1[0] == "getInput" && V1[1] == "PLCDelta") {  //getInput,PLCDelta,#
    getInputDelta();
  } else if (V1[0] == "getCoils" && V1[1] == "PLCDelta") {  //getCoils,PLCDelta,#
    getOutputDelta();
  } else if (V1[0] == "setCoils" && V1[1] == "PLCDelta" && V1[2] == "batch") {  //setCoils,PLCDelta,batch,0,AA,# (setCoils,PLCDelta,,batch,[OutputAddress],[AA = 10101010],#)
    setCoilsBatch(V1[3].toInt(), V1[4]);
  } else if (V1[0] == "setCoils" && V1[1] == "PLCDelta") {  //setCoils,PLCDelta,0,1,# (setCoils,PLCDelta,[OutputAddress],[0:OFF, 1:ON],#)
    setCoilsDelta(V1[2].toInt(), V1[3].toInt());
  } else if (V1[0] == "getData" && V1[1] == "SmartPump") {  //getData,SmartPump,#
    getSmartPump();
  } else if (V1[0] == "getData" && V1[1] == "SmartPumpOld") {  //getData,SmartPumpOld,#
    getSmartPumpOld();
  } else if (V1[0] == "setData" && V1[1] == "SmartPump" && V1[2] == "Mode") {  //setData,SmartPump,Mode,1,#(setData,SmartPump,Mode,[Mode],#)
    setSmartPumpMode(V1[3].toInt());
  } else if (V1[0] == "setData" && V1[1] == "SmartPump" && V1[2] == "PWM") {  //setData,SmartPump,PWM,50,#(setData,SmartPump,PWM,[ValuePWM],#)
    setSmartPumpPWM(V1[3].toInt());
  } else if (V1[0] == "setData" && V1[1] == "SmartPump" && V1[2] == "Timer") {  //setData,SmartPump,Timer,300,#(setData,SmartPump,PWM,[ValueTimer],#)
    setSmartPumpTimer(V1[3].toInt());
  } else if (V1[0] == "setData" && V1[1] == "SmartPump" && V1[2] == "Togle") {  //setData,SmartPump,Togle,#(setData,SmartPump,Togle,#)
    togleSmartPump();
  } else if (V1[0] == "setData" && V1[1] == "SmartPump" && V1[2] == "ModeOld") {  //setData,SmartPump,ModeOld,1,#(setData,SmartPump,Mode,[Mode],#)
    setSmartPumpModeOld(V1[3].toInt());
  } else if (V1[0] == "setData" && V1[1] == "SmartPump" && V1[2] == "PWMOld") {  //setData,SmartPump,PWMOld,50,#(setData,SmartPump,PWM,[ValuePWM],#)
    setSmartPumpPWMOld(V1[3].toInt());
  } else if (V1[0] == "setData" && V1[1] == "SmartPump" && V1[2] == "TimerOld") {  //setData,SmartPump,TimerOld,300,#(setData,SmartPump,PWM,[ValueTimer],#)
    setSmartPumpTimerOld(V1[3].toInt());
  }else if (V1[0] == "startFunction" && V1[1] == "autoZeroCal") {  //startFunction,autoZeroCal,[devID],#
  } else if (V1[0] == "getData" && V1[1] == "AwsHc") {  //getData,AwsHc,#
    // getAwsHc();
    
  } else if(V1[0] == "getData" && V1[1] == "PMOPCNEW"){ //getData,PMOPCNEW,#
    getOPCNEW();
  } else if(V1[0] == "setFlow" && V1[1] == "ZeroNO2"){ //setFlow,ZeroNO2,#
    ZeroNO2();
  } else {
    Serial.println("COMMAND_ERROR;");
  }
}